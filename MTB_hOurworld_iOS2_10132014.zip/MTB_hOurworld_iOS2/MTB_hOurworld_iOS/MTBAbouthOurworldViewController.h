//
//  MTBAbouthOurworldViewController.h
//  MTB_hOurworld_iOS
//
//  Created by Keith Kyungsik Han on 7/6/13.
//  Copyright (c) 2013 HCI PSU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GAITrackedViewController.h"

@interface MTBAbouthOurworldViewController : GAITrackedViewController

@end

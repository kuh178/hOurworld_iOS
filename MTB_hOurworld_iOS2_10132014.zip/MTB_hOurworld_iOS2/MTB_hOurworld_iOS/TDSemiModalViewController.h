//
//  TDSemiModalViewController.h
//  TDSemiModal
//
//  Created by Nathan  Reed on 18/10/10.
//  Copyright 2010 Nathan Reed. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TDSemiModalViewController : UIViewController

@property (nonatomic, strong) UIView *coverView;

@end

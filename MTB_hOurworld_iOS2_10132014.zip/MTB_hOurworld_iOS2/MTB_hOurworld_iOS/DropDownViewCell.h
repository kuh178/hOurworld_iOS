//
//  DropDownViewCell.h
//  KDropDownMultipleSelection
//
//  Created by macmini17 on 03/01/14.
//  Copyright (c) 2014 macmini17. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DropDownViewCell : UITableViewCell

@end

//
//  MTB_hOurworld_iOSTests.h
//  MTB_hOurworld_iOSTests
//
//  Created by Keith Kyungsik Han on 6/5/13.
//  Copyright (c) 2013 HCI PSU. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MTB_hOurworld_iOSTests : SenTestCase

@end

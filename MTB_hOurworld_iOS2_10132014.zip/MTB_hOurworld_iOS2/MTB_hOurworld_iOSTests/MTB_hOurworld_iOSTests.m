//
//  MTB_hOurworld_iOSTests.m
//  MTB_hOurworld_iOSTests
//
//  Created by Keith Kyungsik Han on 6/5/13.
//  Copyright (c) 2013 HCI PSU. All rights reserved.
//

#import "MTB_hOurworld_iOSTests.h"

@implementation MTB_hOurworld_iOSTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MTB_hOurworld_iOSTests");
}

@end
